<html>
<head>
<title>RAWG.io API connection test Page</title>
</head>

<body>
<?php
	//Stephen Lekko's Capstone API connection in PHP.
	//key = 24cad30c5b3949ff9140d8617254ff06

	//get user input as a variable

	//START DB
	$dns = 'mysql:host=localhost;dbname=capstone_db';
	$dbuser = 'stephen';
	$dbpass = 'cowAttorney48';

		try {
			$db = new PDO($dns, $dbuser, $dbpass);
	       	}
		catch (PDOException $e){
			die('PDO error in "lekkoAPI.php": ' . $e->getMessage() );
		}

	//url = "https://api.rawg.io/api/games?key=24cad30c5b3949ff9140d8617254ff06&page_size=1&search=Splatoon"
	//set a variable for search

//	$search_val = $title; //static for testing, change to a variable that takes in user input
		$url = "https://api.rawg.io/api/games?key=24cad30c5b3949ff9140d8617254ff06&page_size=1&search=Bioshock";// . $search_val;
	
		$ch = curl_init();

		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
		curl_setopt($ch, CURLOPT_VERBOSE, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		$response = curl_exec($ch);

		curl_close($ch);

		$data = json_decode($response);

		for($i=0;$i<1;$i++)
		{
			$vgInfo=$response[$i];
			$vgId = $vgInfo->results->id;
			$vgName = $vgInfo->results->name;
			$vgDate = $vgInfo->results->released;
			$vgMeta = $vgInfo->results->metacritic;

    print $vgDate;
    if ($vgDate == "") {
     print "The value vgDate is empty!";
    }
    
		$query = "INSERT INTO rawg_api(rawg_id,rawg_name, rawg_release_date, rawg_metacritic) VALUES('$vgId', '$vgName', '$vgDate', '$vgMeta');";
			$db->exec($query);
		
		}
		print 'PHP Configuration<br>';
		print '====================<p>';
                print $title;
?>

</body>
</html>
