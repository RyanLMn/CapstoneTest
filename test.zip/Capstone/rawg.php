<?php
if ( isset( $_GET['submit'] )){
   echo '<h3>Results:</h3>';
   $title =  $_GET["title"];
   $conn = new mysqli("localhost", "ryan", "pigMachine12", "capstone_db");
   // Check connection
   if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
   }
   $sql = "SELECT * FROM rawg_api WHERE rawg_name = '$title'";
   $sql2 = "SELECT * FROM games WHERE column1  = '$title'";
   $result = $conn->query($sql);
   $result2 = $conn->query($sql2);
   if ($result->num_rows > 0 && $result2->num_rows > 0 ) {
      // output data of each row
      while ($row = $result->fetch_assoc())  {
      	 $row2 = $result2->fetch_assoc();
         if ($row["rawg_metacritic"] == NULL) {
	    echo $row2["column1"] . " was released on " . $row["rawg_release_date"] . " and has no Metacritic Score";
	 } else {
           echo $row2["column1"] . " was released on " . $row["rawg_release_date"] . " with a metacritic score of " . $row["rawg_metacritic"];
	 }
      }
   } else { echo "That game has not been added to our database yet."; }
   $conn->close();
}
?>